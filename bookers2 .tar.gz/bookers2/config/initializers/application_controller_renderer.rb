# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'a3b7c052092d3a9ad3f419ec1000ecf97ba9981928e7489e8301f541ac076799a187dabf49265cc0eb3019fbf65f4e5b7b939ae580a6f74de7a1ec448c36f802'
